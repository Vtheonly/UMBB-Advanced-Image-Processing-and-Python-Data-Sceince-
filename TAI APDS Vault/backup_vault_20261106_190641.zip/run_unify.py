#!/usr/bin/env python3
"""
Direct In-Vault Harmonizer & Deduplicator
Executes directly inside '~/Downloads/TAI APDS Vault'
"""
import os
import re
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

# Auto-detect vault root (whether in ~/Downloads/TAI APDS Vault or ~/Downloads)
VAULT_DIR = Path(".")
if (VAULT_DIR / "TAI APDS Vault").exists():
    VAULT_DIR = VAULT_DIR / "TAI APDS Vault"

print(f"[*] Working inside vault directory: {VAULT_DIR.resolve()}")

# Mapping: Rogue file -> Master destination file
MERGE_MAP = {
    # --- Libraries Cleanup ---
    "Libraries/01.03. NumPy Broadcasting Mechanics and Vectorized Computations.md": (
        "Libraries/04. NumPy Mathematical Engine - Vectorization, ufuncs, and Broadcasting Rules.md"
    ),
    "Libraries/01.11. OpenCV Color Space Transformations and Pixel Math.md": (
        "Libraries/16. OpenCV Core Architecture - Matrix Representation, Channels, and Color Constellations.md"
    ),
    "Libraries/01.13. SciPy Signal and Spatial Operations - 2D Filtering and Morphology.md": (
        "Libraries/19. Spatial Image Restoration - Noise Models, Linear Convolution, and Fast Integral Filters.md"
    ),

    # --- 02. Foundations -> 06.1. Acquisition and Topology ---
    "02. Foundations/02.1. Physical Image Formation and Optical Sensing.md": (
        "06. Advanced Image Processing (TAI)/06.1. Acquisition and Topology/06.1. Digital Image Acquisition, Matrix Topologies, and Fixed Thresholding (TP1).md"
    ),
    "02. Foundations/02.2. Discretization - Spatial Sampling and Nyquist-Shannon Theorem.md": (
        "06. Advanced Image Processing (TAI)/06.1. Acquisition and Topology/06.1. Digital Image Acquisition, Matrix Topologies, and Fixed Thresholding (TP1).md"
    ),
    "02. Foundations/02.4. Image Representations - Raster Matrix vs Mathematical Vector Primitives.md": (
        "06. Advanced Image Processing (TAI)/06.1. Acquisition and Topology/06.2. Spatial Transformations, ROI Extraction, and Multi-Channel Histograms (TP1).md"
    ),

    # --- 03. Preprocessing -> 06.2. Spatial Restoration & 06.3. Non-Linear ---
    "03. Preprocessing/03.3. Linear Smoothing Filters - Box Mean and Separable Gaussian Convolutions.md": (
        "06. Advanced Image Processing (TAI)/06.2. Spatial Restoration and Smoothing/06.3. Discrete Noise Models and Spatial Convolution Smoothing (TP2 Part 1).md"
    ),
    "03. Preprocessing/03.4. Spatial High-Pass Filtering - Differential Operators and Laplacian Sharpening.md": (
        "06. Advanced Image Processing (TAI)/06.2. Spatial Restoration and Smoothing/06.3. Discrete Noise Models and Spatial Convolution Smoothing (TP2 Part 1).md"
    ),
    "03. Preprocessing/03.8. Specialized Spectral Operators - Band-Reject Notch Filters and Directional Gabor Filter Banks.md": (
        "06. Advanced Image Processing (TAI)/06.2. Spatial Restoration and Smoothing/06.4. Fast Integral Filtering and Adaptive Spatial Smoothing (TP2 Part 1 Homework).md"
    ),
    "03. Preprocessing/03.5. Order-Statistic Non-Linear Filtering - Median and Rank-Order Min-Max Operators.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),
    "03. Preprocessing/03.6. Structural Edge-Preserving Smoothing - The Nagao Adaptive Multi-Sector Filter.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),
    "03. Preprocessing/03.9. Non-Linear Boundary-Preserving Filtering - The Joint Spatial-Radiometric Bilateral Filter.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),
    "03. Preprocessing/03.10. Partial Differential Equations in Restoration - Perona-Malik Anisotropic Diffusion.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),
    "03. Preprocessing/03.11. Feature Space Clustering Segmentation - Mean-Shift and 2SP-DBSCAN.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),
    "03. Preprocessing/03.16. Deep Learning Denoising Architectures - From Patch MLPs to Residual DnCNN and Uformer.md": (
        "06. Advanced Image Processing (TAI)/06.3. Non-Linear Edge Preservation/06.5. Edge-Preserving Non-Linear Smoothing with the Nagao Filter (TP2 Part 2).md"
    ),

    # --- 04. Segmentation -> 06. Advanced Image Processing (TAI)/06.7. Segmentation ---
    "04. Segmentation/04.1. Formal Segmentation Axioms and Homogeneity Predicates.md": (
        "06. Advanced Image Processing (TAI)/06.7. Segmentation and Feature Extraction/06.9. Image Segmentation Axioms, Thresholding, and Connected Components.md"
    ),
    "04. Segmentation/04.3. Local Adaptive Thresholding - Niblack and Dynamic Range-Constrained Sauvola Algorithms.md": (
        "06. Advanced Image Processing (TAI)/06.7. Segmentation and Feature Extraction/06.9. Image Segmentation Axioms, Thresholding, and Connected Components.md"
    ),
    "04. Segmentation/04.5. Morphological Watershed Segmentation and Topological Distance Transforms.md": (
        "06. Advanced Image Processing (TAI)/06.7. Segmentation and Feature Extraction/06.9. Image Segmentation Axioms, Thresholding, and Connected Components.md"
    ),
    "04. Segmentation/04.6. Connected Component Analysis - Two-Pass Labeling and Equivalence Trees.md": (
        "06. Advanced Image Processing (TAI)/06.7. Segmentation and Feature Extraction/06.9. Image Segmentation Axioms, Thresholding, and Connected Components.md"
    ),

    # --- 05. Super Resolution -> 06.6. Single-Frame Super-Resolution ---
    "05. Super Resolution/05.2. Directional Reconstruction - Contour Stencils and Total Variation Minimization.md": (
        "06. Advanced Image Processing (TAI)/06.6. Single-Frame Super-Resolution/06.8. Single-Frame Super-Resolution and Getreuer Contour Stencils (TP2 Part 5).md"
    ),
    "05. Super Resolution/05.4. Document Image Enhancement - Bi-ESRGAN Dual Path Architecture.md": (
        "06. Advanced Image Processing (TAI)/06.6. Single-Frame Super-Resolution/06.8. Single-Frame Super-Resolution and Getreuer Contour Stencils (TP2 Part 5).md"
    ),

    # --- Laboratories, Exercises, Projects -> 06.8. Practical Exercises ---
    "06. Laboratories/06.3. Laboratory 3 - Algorithmic Engineering of the Nagao Edge-Preserving Filter.md": (
        "06. Advanced Image Processing (TAI)/06.8. Practical Exercises and Solutions/06.10. Worked Image Processing Exercises and End-to-End Solutions.md"
    ),
    "07. Exercises/07.1. Exercise 1 - Complete Calculation of 2D Convolution and Boundary Padding Modes.md": (
        "06. Advanced Image Processing (TAI)/06.8. Practical Exercises and Solutions/06.10. Worked Image Processing Exercises and End-to-End Solutions.md"
    ),
    "07. Exercises/07.3. Exercise 3 - Analytical Sub-Pixel Reconstruction via Bilinear Interpolation.md": (
        "06. Advanced Image Processing (TAI)/06.8. Practical Exercises and Solutions/06.10. Worked Image Processing Exercises and End-to-End Solutions.md"
    ),
    "09. Projects/09.1. Applied Project - End-to-End Document Cleaning and Text Extraction Pipeline.md": (
        "06. Advanced Image Processing (TAI)/06.8. Practical Exercises and Solutions/06.10. Worked Image Processing Exercises and End-to-End Solutions.md"
    ),

    # --- 00. Navigation -> Roadmap & MOC ---
    "00. Navigation/00.0. Master Verification Matrix and File Map.md": (
        "06. Advanced Image Processing (TAI)/06.0. Advanced Image Processing Index and Curriculum MOC.md"
    ),
    "00. Navigation/00.1. Master Index and Knowledge Graph MOC.md": (
        "06. Advanced Image Processing (TAI)/06.0. Advanced Image Processing Index and Curriculum MOC.md"
    ),
    "00. Navigation/00.2. Course Roadmap and Unified Learning Path.md": (
        "00. Master Curriculum Roadmap.md"
    ),
}

ROGUE_DIRS = [
    "00. Navigation",
    "02. Foundations",
    "03. Preprocessing",
    "04. Segmentation",
    "05. Super Resolution",
    "06. Laboratories",
    "07. Exercises",
    "09. Projects",
]

# 1. Backup Vault
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
backup_file = VAULT_DIR.parent / f"backup_vault_{ts}.zip"
print(f"[*] Creating zip backup at {backup_file.name} ...")
with zipfile.ZipFile(backup_file, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, _, files in os.walk(VAULT_DIR):
        for f in files:
            p = Path(root) / f
            zf.write(p, p.relative_to(VAULT_DIR))

# 2. Merge content into master notes
print("[*] Merging content into master notes...")
link_redirects = {}

for src_rel, dest_rel in MERGE_MAP.items():
    src_p = VAULT_DIR / src_rel
    dest_p = VAULT_DIR / dest_rel
    link_redirects[src_p.stem] = dest_p.stem

    if not src_p.exists():
        continue

    src_content = src_p.read_text(encoding="utf-8")
    # Clean leading title
    lines = src_content.splitlines()
    while lines and (lines[0].startswith("# ") or not lines[0].strip() or lines[0].strip() == "---"):
        lines.pop(0)
    clean_body = "\n".join(lines).strip()

    if not dest_p.exists():
        dest_p.parent.mkdir(parents=True, exist_ok=True)
        dest_p.write_text(src_content, encoding="utf-8")
        src_p.unlink()
        print(f"  [Created Target] {dest_rel}")
    else:
        dest_content = dest_p.read_text(encoding="utf-8")
        if clean_body[:80].lower() not in dest_content.lower():
            divider = f"\n\n---\n\n## Integrated Subject Knowledge: {src_p.stem}\n\n"
            dest_p.write_text(dest_content.rstrip() + divider + clean_body + "\n", encoding="utf-8")
            print(f"  [Merged] {src_rel} -> {dest_rel}")
        src_p.unlink()

# 3. Delete rogue top-level directories
print("[*] Removing rogue top-level folders...")
for r_dir in ROGUE_DIRS:
    d = VAULT_DIR / r_dir
    if d.exists() and d.is_dir():
        shutil.rmtree(d, ignore_errors=True)
        print(f"  [DELETED] {r_dir}/")

# 4. Harmonize wikilinks
print("[*] Harmonizing Obsidian wikilinks...")
pattern = re.compile(r"\[\[([^\|\]]+?)(\|[^\]]+)?\]\]")
count = 0
for md in VAULT_DIR.rglob("*.md"):
    text = md.read_text(encoding="utf-8")
    def repl(m):
        t, d = m.group(1).strip(), m.group(2) or ""
        return f"[[{link_redirects.get(t, t)}{d}]]"
    new_text = pattern.sub(repl, text)
    if new_text != text:
        md.write_text(new_text, encoding="utf-8")
        count += 1

# Clean up script itself
Path("run_unify.py").unlink(missing_ok=True)

print(f"\n[OK] Success! Vault unified. Updated links across {count} notes.")
print("=" * 60)
